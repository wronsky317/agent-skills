---
name: luna-subagent
description: Configure and proactively use the bundled luna-subagent custom Codex agent for clear, narrowly scoped, repeatable work with explicit completion criteria, including focused inspection, mechanical edits, validation, and batch processing. Use when the user mentions Luna or luna-subagent, asks to install or manage its custom-agent configuration, or when a bounded task benefits from a fast isolated worker. Do not use for ambiguous, high-risk, or architecture-heavy tasks.
---

# Luna Subagent

## Overview

Use this self-contained Skill to install, validate, update, and invoke the bundled `luna-subagent` custom agent. Resolve every resource relative to this `SKILL.md`; do not depend on a source checkout, Downloads directory, or a separately maintained Agent template.

The bundle owns:

- `assets/agent.toml`: the canonical custom-Agent definition and defaults.
- `scripts/manage_luna_agent.py`: deterministic installation, diff, backup, and validation.
- `scripts/_vendor/tomli/`: TOML parsing fallback for Python versions before 3.11.
- `references/extending.md`: instructions for copying or extending the bundle.

## Workflow

### 1. Classify the request

- **Run a task:** preflight the Agent configuration, spawn `luna-subagent`, wait, verify, and summarize.
- **Manage configuration:** inspect, install, update, repair, or report the configuration without spawning work.
- **Extend or fork the Skill:** read `references/extending.md` before editing names, defaults, templates, or routing behavior.
- **No task payload:** finish the requested configuration work and ask for a concrete task; do not invent one.

Use Luna only for clear, narrow, repeatable work with explicit completion criteria. Ask for a tighter boundary or use a general-purpose agent when the task is ambiguous, high-risk, or architecture-heavy.

### 2. Preflight the custom Agent

From the Skill directory, run:

```bash
python3 scripts/manage_luna_agent.py show
python3 scripts/manage_luna_agent.py check
```

The manager derives the target filename, model, reasoning effort, service tier, and Agent name from `assets/agent.toml`.

Handle the result as follows:

1. **Already up to date:** continue without writing.
2. **Target missing:** run `python3 scripts/manage_luna_agent.py apply`, then repeat `show` and `check`.
3. **Existing target differs:** show the unified diff and obtain explicit confirmation before running `apply --yes`. The manager creates a timestamped backup.
4. **Template, catalog, parsing, or write failure:** stop and report the exact blocker. Do not spawn an unverified Agent.

Use `--model`, `--reasoning-effort`, or `--service-tier` only when the user explicitly requests an override. Verify requests for the latest or recommended model against current official Codex documentation; never guess or silently substitute a model.

### 3. Delegate the task

After preflight succeeds, spawn the custom agent with `agent_type` set to `luna-subagent`. Give it one bounded task with explicit completion criteria and relevant paths. Let the verified Agent file provide its model and reasoning settings; do not pass duplicate model overrides.

Wait for completion, inspect the reported result, and perform proportionate parent-side verification. If the multi-agent tool is unavailable or spawning fails, report the blocker rather than pretending the task ran.

## Decision Rules

- Keep routing in this Skill and role behavior in `assets/agent.toml`.
- Do not let Luna delegate further unless the parent explicitly asks.
- Do not overwrite a differing existing Agent file without current-task confirmation.
- Do not hand-edit the installed target when the bundled manager can perform the change.
- Do not modify unrelated Codex configuration files.

## Verification

Before reporting success, require:

- `manage_luna_agent.py check` exits successfully and reports `already up to date`.
- The parsed Agent name and requested model settings match the bundled template or explicit overrides.
- Any replacement reports the backup path.
- A delegated task includes its own result, relevant paths, verification, and caveats.

For repository maintenance or forking, also run the repository Skill validator described in `references/extending.md`.
