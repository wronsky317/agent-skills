"""Vendored compatibility dependencies for the Luna agent manager."""
