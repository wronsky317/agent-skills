#!/usr/bin/env python3
"""Safely install, inspect, and update the luna-subagent Codex config."""

from __future__ import annotations

import argparse
import difflib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import subprocess
import tempfile
from datetime import datetime

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11
    # Vendored tomli 2.3.0; see scripts/_vendor/tomli/LICENSE.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from _vendor import tomli as tomllib  # type: ignore[no-redef]


SKILL_DIR = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_DIR / "assets" / "agent.toml"
EFFORTS = ("minimal", "low", "medium", "high", "xhigh", "max", "ultra")
MODEL_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]*$")
MODEL_CATALOG_TIMEOUT_SEC = 20


def load_template() -> str:
    """Read the canonical custom-Agent template bundled with this Skill."""
    if not TEMPLATE_PATH.is_file():
        raise ValueError(f"Bundled Agent template is missing: {TEMPLATE_PATH}")
    return TEMPLATE_PATH.read_text(encoding="utf-8")


def render(model: str, effort: str, service_tier: str) -> str:
    validate_model(model)
    template = load_template()
    template_values = validate(template)
    agent_name = template_values["name"]
    updated = set_top_level_string(template, "model", model)
    updated = set_top_level_string(updated, "model_reasoning_effort", effort)
    updated = set_top_level_string(updated, "service_tier", service_tier)
    updated = set_table_bool(updated, "features", "fast_mode", service_tier == "fast")
    validate(updated, model, effort, service_tier, expected_name=agent_name)
    return updated


def validate_model(model: str) -> None:
    if not MODEL_PATTERN.fullmatch(model):
        raise ValueError(f"Invalid model slug: {model!r}")


def verify_model_support(model: str, effort: str, service_tier: str) -> None:
    """Verify the requested model settings against this Codex installation."""
    validate_model(model)
    try:
        result = subprocess.run(
            ["codex", "debug", "models"],
            capture_output=True,
            text=True,
            check=False,
            timeout=MODEL_CATALOG_TIMEOUT_SEC,
        )
    except FileNotFoundError as exc:
        raise ValueError("Cannot verify model availability: 'codex' is not on PATH.") from exc
    except subprocess.TimeoutExpired as exc:
        raise ValueError("Timed out while reading the Codex model catalog.") from exc
    if result.returncode != 0:
        detail = result.stderr.strip() or "unknown Codex error"
        raise ValueError(f"Cannot read the Codex model catalog: {detail}")
    try:
        catalog = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError("Codex returned an unreadable model catalog.") from exc

    entry = next(
        (
            item
            for item in catalog.get("models", [])
            if item.get("slug") == model or item.get("id") == model or item.get("model") == model
        ),
        None,
    )
    if entry is None:
        raise ValueError(f"Model {model!r} is not available in the current Codex catalog.")

    levels = set()
    for level in entry.get("supported_reasoning_levels", []):
        levels.add(level if isinstance(level, str) else level.get("effort"))
    if effort not in levels:
        supported = ", ".join(sorted(value for value in levels if value)) or "none"
        raise ValueError(
            f"Reasoning effort {effort!r} is not supported by {model!r}; "
            f"supported values: {supported}."
        )

    tiers = entry.get("service_tiers", [])
    advertised_values = {
        str(value).lower()
        for tier in tiers
        if isinstance(tier, dict)
        for value in (tier.get("id"), tier.get("name"))
        if value
    }
    supports_fast = any(
        isinstance(tier, dict)
        and (
            tier.get("id") in {"fast", "priority"}
            or str(tier.get("name", "")).lower() == "fast"
        )
        for tier in tiers
    )
    if service_tier == "fast" and not supports_fast:
        advertised = ", ".join(
            str(tier.get("id"))
            for tier in tiers
            if isinstance(tier, dict) and tier.get("id")
        ) or "none"
        raise ValueError(
            f"Service tier {service_tier!r} is not supported by {model!r}; "
            f"advertised tiers: {advertised}."
        )
    if service_tier != "fast" and service_tier.lower() not in advertised_values:
        advertised = ", ".join(sorted(advertised_values)) or "none"
        raise ValueError(
            f"Service tier {service_tier!r} is not supported by {model!r}; "
            f"advertised tiers: {advertised}."
        )


def set_top_level_string(content: str, key: str, value: str) -> str:
    """Replace or insert a top-level TOML string while preserving other content."""
    replacement = f"{key} = {json.dumps(value)}\n"
    lines = content.splitlines(keepends=True)
    table_started = False
    key_pattern = re.compile(rf"^\s*{re.escape(key)}\s*=")
    for index, line in enumerate(lines):
        if re.match(r"^\s*\[", line):
            table_started = True
        if not table_started and key_pattern.match(line):
            lines[index] = replacement
            return "".join(lines)

    insert_at = next(
        (index for index, line in enumerate(lines) if re.match(r"^\s*\[", line)),
        len(lines),
    )
    if insert_at > 0 and not lines[insert_at - 1].endswith(("\n", "\r")):
        lines[insert_at - 1] += "\n"
    lines.insert(insert_at, replacement)
    return "".join(lines)


def set_table_bool(content: str, table: str, key: str, value: bool) -> str:
    """Replace or insert a boolean in an exact TOML table."""
    replacement = f"{key} = {'true' if value else 'false'}\n"
    lines = content.splitlines(keepends=True)
    table_pattern = re.compile(rf"^\s*\[{re.escape(table)}\]\s*(?:#.*)?$")
    key_pattern = re.compile(rf"^\s*{re.escape(key)}\s*=")
    table_start = next(
        (
            index
            for index, line in enumerate(lines)
            if table_pattern.match(line.rstrip("\r\n"))
        ),
        None,
    )

    if table_start is None:
        if lines and lines[-1].strip():
            lines.append("\n")
        lines.extend((f"[{table}]\n", replacement))
        return "".join(lines)

    table_end = next(
        (
            index
            for index in range(table_start + 1, len(lines))
            if re.match(r"^\s*\[", lines[index])
        ),
        len(lines),
    )
    for index in range(table_start + 1, table_end):
        if key_pattern.match(lines[index]):
            lines[index] = replacement
            return "".join(lines)
    lines.insert(table_end, replacement)
    return "".join(lines)


def desired_content(model: str, effort: str, service_tier: str) -> str:
    verify_model_support(model, effort, service_tier)
    return render(model, effort, service_tier)


def validate(
    content: str,
    model: str | None = None,
    effort: str | None = None,
    service_tier: str | None = None,
    expected_name: str | None = None,
) -> dict:
    try:
        parsed = tomllib.loads(content)
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"Invalid TOML: {exc}") from exc

    required = ("name", "description", "developer_instructions")
    missing = [key for key in required if not parsed.get(key)]
    if missing:
        raise ValueError(f"Missing required fields: {', '.join(missing)}")
    if expected_name is not None and parsed["name"] != expected_name:
        raise ValueError(f"The agent name must be {expected_name!r}.")
    if model is not None and parsed.get("model") != model:
        raise ValueError("The parsed model does not match the requested model.")
    if effort is not None and parsed.get("model_reasoning_effort") != effort:
        raise ValueError("The parsed reasoning effort does not match the request.")
    if service_tier is not None and parsed.get("service_tier") != service_tier:
        raise ValueError("The parsed service tier does not match the request.")
    if service_tier == "fast" and parsed.get("features", {}).get("fast_mode") is not True:
        raise ValueError("Fast service tier requires features.fast_mode = true.")
    return parsed


def read_existing(target: Path) -> str | None:
    if not target.exists():
        return None
    if not target.is_file():
        raise ValueError(f"Target exists but is not a regular file: {target}")
    return target.read_text(encoding="utf-8")


def print_current(target: Path, content: str | None) -> None:
    print(f"Target: {target}")
    if content is None:
        print("Status: missing")
        return
    print("Current content:")
    print(content, end="" if content.endswith("\n") else "\n")


def print_diff(current: str | None, desired: str, target: Path) -> None:
    before = current.splitlines(keepends=True) if current is not None else []
    after = desired.splitlines(keepends=True)
    diff = difflib.unified_diff(
        before,
        after,
        fromfile=str(target) if current is not None else "/dev/null",
        tofile=str(target),
    )
    print("Desired diff:")
    rendered = "".join(diff)
    print(rendered, end="" if rendered.endswith("\n") else "\n")


def atomic_write(target: Path, content: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, target)
    finally:
        temp_path.unlink(missing_ok=True)


def target_path(value: str | None, agent_name: str) -> Path:
    if value:
        return Path(value).expanduser().resolve()
    return (Path.home() / ".codex" / "agents" / f"{agent_name}.toml").resolve()


def main() -> int:
    try:
        template = load_template()
        template_values = validate(template)
        agent_name = template_values["name"]
        default_model = template_values.get("model")
        default_effort = template_values.get("model_reasoning_effort")
        default_service_tier = template_values.get("service_tier")
        missing_defaults = [
            key
            for key, value in (
                ("model", default_model),
                ("model_reasoning_effort", default_effort),
                ("service_tier", default_service_tier),
            )
            if not value
        ]
        if missing_defaults:
            raise ValueError(
                "Bundled Agent template is missing defaults: "
                + ", ".join(missing_defaults)
            )
        validate(
            template,
            default_model,
            default_effort,
            default_service_tier,
            expected_name=agent_name,
        )
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("show", "check", "apply"))
    parser.add_argument("--model", default=default_model)
    parser.add_argument("--reasoning-effort", choices=EFFORTS, default=default_effort)
    parser.add_argument("--service-tier", default=default_service_tier)
    parser.add_argument(
        "--target",
        help=f"Override the installed Agent path (default: ~/.codex/agents/{agent_name}.toml).",
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Authorize replacement when the target file already differs.",
    )
    args = parser.parse_args()
    target = target_path(args.target, agent_name)

    try:
        current = read_existing(target)
        if args.action == "show":
            print_current(target, current)
            if current is not None:
                parsed = validate(current, expected_name=agent_name)
                print(
                    "Validation: valid TOML; "
                    f"name={parsed['name']}; model={parsed.get('model', '<inherited>')}; "
                    f"reasoning_effort={parsed.get('model_reasoning_effort', '<inherited>')}; "
                    f"service_tier={parsed.get('service_tier', '<inherited>')}; "
                    f"fast_mode={parsed.get('features', {}).get('fast_mode', '<inherited>')}"
                )
                if any(
                    key not in parsed
                    for key in ("model", "model_reasoning_effort", "service_tier")
                ):
                    print("Status: valid custom agent, but one or more defaults are inherited")
            return 0

        desired = desired_content(args.model, args.reasoning_effort, args.service_tier)
        print_current(target, current)
        if current == desired:
            print("Status: already up to date")
            return 0
        print_diff(current, desired, target)

        if args.action == "check":
            print("Status: update required")
            return 2
        if current is not None and not args.yes:
            print("Refusing to replace an existing file without --yes.", file=sys.stderr)
            return 3

        backup = None
        if current is not None:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            backup = target.with_name(f"{target.name}.bak.{timestamp}")
            suffix = 1
            while backup.exists():
                backup = target.with_name(f"{target.name}.bak.{timestamp}-{suffix}")
                suffix += 1
            shutil.copy2(target, backup)
        atomic_write(target, desired)
        written = target.read_text(encoding="utf-8")
        validate(
            written,
            args.model,
            args.reasoning_effort,
            args.service_tier,
            expected_name=agent_name,
        )
        print(f"Status: {'updated' if current is not None else 'created'}")
        if backup is not None:
            print(f"Backup: {backup}")
        print("Validation: valid TOML and requested values verified")
        return 0
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
