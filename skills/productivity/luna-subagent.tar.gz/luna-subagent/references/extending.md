# Extending Luna Subagent

Use this reference when changing Luna's role, defaults, installation behavior, or when copying the bundle to create another custom Agent.

## Bundle contract

Keep the following responsibilities separate:

| File | Responsibility |
|---|---|
| `SKILL.md` | Trigger boundary, routing, preflight, delegation, and verification workflow |
| `assets/agent.toml` | Canonical custom-Agent name, role instructions, model, effort, tier, and session settings |
| `scripts/manage_luna_agent.py` | Deterministic template installation, catalog checks, diffs, backups, and validation |
| `agents/openai.yaml` | Skill UI metadata and implicit-invocation policy |

The manager derives the installed filename and CLI defaults from the bundled TOML. Changing the template therefore changes what `check` and `apply` consider canonical.

## Change Luna in place

1. Edit `assets/agent.toml` for role instructions or default session settings.
2. Edit the `SKILL.md` description when the trigger boundary changes.
3. Update `agents/openai.yaml` when the display text or invocation policy changes.
4. Run the validations below.
5. On an existing installation, run `check`, review the diff, then use `apply --yes` only after confirmation. Preserve the reported backup.

## Fork a new custom Agent

1. Copy the entire Skill directory, excluding generated caches such as `__pycache__`.
2. Rename the directory using lowercase hyphen-case.
3. Change `name` in `SKILL.md` to match the directory.
4. Change `name` in the bundled TOML. The manager will derive `~/.codex/agents/<name>.toml` automatically.
5. Update the Skill description, Agent description, developer instructions, model defaults, and UI metadata.
6. Replace Luna-specific wording in `SKILL.md` and `agents/openai.yaml`.
7. Keep `scripts/_vendor/tomli/LICENSE` when redistributing the vendored parser.
8. Run validation and isolated manager tests before linking the new Skill.

## Validation

From the shared repository root:

```bash
python3 scripts/validate-skills.py
python3 ~/.codex/skills/.system/skill-creator/scripts/quick_validate.py skills/productivity/luna-subagent
```

Test installation against a temporary target so the live Agent is untouched:

```bash
tmp_dir="$(mktemp -d)"
python3 skills/productivity/luna-subagent/scripts/manage_luna_agent.py show \
  --target "$tmp_dir/luna-subagent.toml"
python3 skills/productivity/luna-subagent/scripts/manage_luna_agent.py apply \
  --target "$tmp_dir/luna-subagent.toml"
python3 skills/productivity/luna-subagent/scripts/manage_luna_agent.py check \
  --target "$tmp_dir/luna-subagent.toml"
```

Remove the temporary directory after inspecting the output. Do not use temporary tests to bypass model-catalog validation.
